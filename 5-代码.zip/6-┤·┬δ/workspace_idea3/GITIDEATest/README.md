# GITIDEATest
在IDEA上测试Git的使用
