package com.atguigu.bean;

public class Customer extends Person{

    public static void main(String[] args){


        System.out.println("helloworld!!!!");
    }

    public void eat(){
        System.out.println("客户吃饭");
    }
}
