package com.atguigu.bean;

/**
 * @author shkstart
 * @date 2018/7/12 0012 - 下午 5:16
 */
public class Person {

    public void eat(){
        System.out.println("吃饭");
    }
}
