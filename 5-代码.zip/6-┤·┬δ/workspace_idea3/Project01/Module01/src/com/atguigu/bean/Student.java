package com.atguigu.bean;

/**
 * @author shkstart
 * @date 2018/7/12 0012 - 下午 5:17
 */
public class Student extends Person {


}
