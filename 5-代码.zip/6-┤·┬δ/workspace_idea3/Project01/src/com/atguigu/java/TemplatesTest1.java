package com.atguigu.java;

/**
 * @author shkstart
 * @date 2018/7/13 0013 - 下午 1:59
 */
public class TemplatesTest1 {
    
    //生成的模板的演示2
    /**
     * 客户的id
     */
    private int id;
    
    /**
     * 客户的姓名
     */
     private String name;
     
    
    
    //修改2：
    public static final int NUM = 10;
    

    //修改1： psvm -> main
    public static void main(String[] args) {

    }
    //生成的模板的演示1
    public void testUpdate(){
        //修改的测试
    }


}
